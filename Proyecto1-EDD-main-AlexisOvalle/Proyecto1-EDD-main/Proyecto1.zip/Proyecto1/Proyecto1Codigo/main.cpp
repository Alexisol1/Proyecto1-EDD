#include <iostream>
#include <string>
#include <ctime>
#include <stdlib.h>
#include <vector>
#include<stdio.h>
#include<string.h>
#include <chrono>
#include "persona.h"
#include "partida.h"
using namespace std;
// VARIABLES GLOBALES
chrono::steady_clock sc; // create an object of `steady_clock` class

int cantidadMovimientos = 0;
int cantidadPartidas = 0;
personas1 *personasArregloFinal;
std::vector<personas1> personasArrayFinal;
std::vector<Partida> partidasArreglo;



void SetAll(std::string nombre, int cantidadPunteo, int pasosTotales, double tiempoPartida)
{
}

void ToString() {}

void ingresoNombre()
{
    string nombre;
    cout << "ingrese su nombre de usuario" << endl;
    cin >> nombre;
}
string seleccionPeronaje()
{
    string nombre;
    cout << "escriba el numero que le corresponde al usuario" << endl;
    int seleccionUsuario;
    for (size_t i = 0; i < 19; i++)
    {
    }
    cin >> seleccionUsuario;

    return nombre;
}

//-------------------PARA JUGAR---------------------------------------------------------

void generacionTablero()
{
}
void nuevo()
{
    int cantidad = 0;
    std::cout << "INgreso cantidad" << std::endl;
    std::cin >> cantidad;

    personas1 animalesArray[cantidad];
    animalesArray[0].SetAll("si");
    // animalesArray[1].SetAll("no");

    for (size_t i = 0; i < cantidad; i++)
    {
        std::cout << animalesArray[i].getNombre() + "\n";
    }
}
void generacionPersona()
{
    nuevo();
}
// INGRESO DE USUARIOS
void ingresarUsuarios()
{
    cout << "-----Ingrese el nombre de usuario-------\n";
    string nombre;
    cin >> nombre;
    bool nombreIngresadoPrevio = false;
    // personasArregloFinal = new personas1[cantidadArreglo+1];
    for (size_t i = 0; i < personasArrayFinal.size(); i++)
    {
        if (nombre == personasArrayFinal[i].getNombre())
        {
            nombreIngresadoPrevio = true;
            break;
        }
    }
    if (!nombreIngresadoPrevio)
    {
        personas1 personaTempo(nombre);
        personasArrayFinal.push_back(personaTempo);

        cout << "se ha ingreso a " << nombre << " exitosamente" << endl;
    }
}
// vista para los jugadores

void mostrarJugadores()
{
    cout << "-----Usuarios ingresasos-------\n";
    for (size_t i = 0; i < personasArrayFinal.size(); i++)
    {
        cout << " " << i << " " << personasArrayFinal[i].getNombre() << endl;
    }
}

void generacionUsuario()
{
    int seleccion;
    do
    {
        std::cout << "Para comenzar el juego debe se seleccionar su usario o crear uno\n";
        std::cout << "1. Crear Usuario" << std::endl
                  << " 2. Ver usuarios" << std::endl
                  << " 3. Regresar\n";
        std::cin >> seleccion;
        switch (seleccion)
        {
        case 1:
            ingresarUsuarios();
            break;
        case 2:
            // Ver Reportes
            mostrarJugadores();
            break;
        case 3:
            // FIn juego
            cout << "Regresando al menu de juego" << endl;
            break;
        default:
            // presiona algo mas
            cout << "No existe esta opcion" << endl;
            break;
        }
    } while (seleccion != 3);
}

// return numero del usuario

// METODOS Y FUNCIONALIDES DEL JUEGO
enum EMove
{
    keUp = 'w',
    keDown = 's',
    keLeft = 'a',
    keRight = 'd',
    terminateGame = 'x'
};
void InitializeBoard(string[4][4]);
void PrintBoard(string[4][4]);
void LocateSpace(int &, int &, string[4][4]);
void Randomize(string[4][4]);
void Move(string[4][4], const EMove);

void InitializeBoard(string caaBoard[4][4])
{
    const string kcaaInitial[4][4] = {
        {"1", "2", "3", "4"},
        {"5", "6", "7", "8"},
        {"9", "10", "11", "12"},
        {"13", "14", "15", "X"}};
    for (int iRow = 0; iRow < 4; ++iRow)
    {
       
        for (int iCol = 0; iCol < 4; ++iCol)
        {
            caaBoard[iRow][iCol] = kcaaInitial[iRow][iCol];
        }
    }
}

void PrintBoard(string caaBoard[4][4])
{
    using namespace std;
    for (int iRow = 0; iRow < 4; ++iRow)
    {
         cout<<"\n-------------------------"<<endl;
        for (int iCol = 0; iCol < 4; ++iCol)
        {
            cout <<"| " <<caaBoard[iRow][iCol]<<" |";
        }
        cout << endl;
    }
}

void LocateSpace(int &irRow, int &irCol, string caaBoard[4][4])
{
    for (int iRow = 0; iRow < 4; ++iRow)
    {
        for (int iCol = 0; iCol < 4; ++iCol)
        {
            if (caaBoard[iRow][iCol] == "X")
            {
                irRow = iRow;
                irCol = iCol;
            }
        }
    }
}

void Randomize(string caaBoard[4][4])
{
    using namespace std;
    srand((unsigned int)time(0));
    for (int iIndex = 0; iIndex < 1000000; ++iIndex)
    {
        const int kiNextMove = (rand() % 4);
        switch (kiNextMove)
        {
        case 0:
        {
            Move(caaBoard, keUp);
            break;
        }
        case 1:
        {
            Move(caaBoard, keDown);
            break;
        }
        case 2:
        {
            Move(caaBoard, keLeft);
            break;
        }
        case 3:
        {
            Move(caaBoard, keRight);
            break;
        }
        }
    }
}

void Move(string caaBoard[4][4], const EMove keMove)
{
    int iRowSpace;
    int iColSpace;
    LocateSpace(iRowSpace, iColSpace, caaBoard);
    int iRowMove(iRowSpace);
    int iColMove(iColSpace);
    switch (keMove)
    {
    case keDown:
    {
        iRowMove = iRowSpace + 1;
        cantidadMovimientos++;
        break;
    }
    case keUp:
    {
        iRowMove = iRowSpace - 1;
        cantidadMovimientos++;
        break;
    }
    case keRight:
    {
        iColMove = iColSpace + 1;
        cantidadMovimientos++;
        break;
    }
    case keLeft:
    {
        iColMove = iColSpace - 1;
        cantidadMovimientos++;
        break;
    }
    }
    // Make sure that the square to be moved is in bounds
    if (iRowMove >= 0 && iRowMove < 4 && iColMove >= 0 && iColMove < 4)
    {
        caaBoard[iRowSpace][iColSpace] = caaBoard[iRowMove][iColMove];
        caaBoard[iRowMove][iColMove] = "X";
    }
}
int comprobarPuntaje(string caaBoard[4][4]) {
     int cantidadPuntos=0;
     const string matriz[4][4] = {
        {"1", "2", "3", "4"},
        {"5", "6", "7", "8"},
        {"9", "10", "11", "12"},
        {"13", "14", "15", "X"}};
    
    for (size_t i = 0; i < 4; i++)
    {
        for (size_t j = 0; j < 4; j++)
        {
            if ((caaBoard[i][j]==(matriz[i][j]))) {
                cantidadPuntos = cantidadPuntos+2;
            }
        }
        
    }
    return cantidadPuntos;
}

void imprimirMatriz(string matriz[4][4]) {
for (size_t i = 0; i < 4; i++)
{
    for (size_t j = 0; j < 4; j++)
    {
        cout<<matriz[i][j];
    }
    
}

}
//-------------------------------------
void jugar()
{

    
    // Aqui eestablezco el juego
    auto start = sc.now(); // Comienza a contar el tiempo
    // le solicito al usuario que seleccione con que "usuario" jugara
    cout << "Escriba el numero del usuario con el que jugara" << endl;
    mostrarJugadores();
    int seleccionJugador;
    cin >> seleccionJugador;
    bool jugadorEncontrado = false;

    for (size_t i = 0; i < personasArrayFinal.size(); i++)
    {
        if (seleccionJugador == i)
        {
            cout << "Jugara con el usuario: " << personasArrayFinal[i].getNombre();
            jugadorEncontrado = true;
            break;
        }
    }

    if (jugadorEncontrado)
    {
        string caaBoard[4][4];
        InitializeBoard(caaBoard);
        Randomize(caaBoard);
        bool continuacion = true;
        do
        {
            PrintBoard(caaBoard);
            int pasos = cantidadMovimientos - 1000000;
            cout<<"Nombre del jugador: "<<personasArrayFinal[seleccionJugador].getNombre()<<"\t";
            cout << "Cantidad de Movimientos: " << pasos << endl;
            cout << endl
                 << "w = Arriba - s = Abajo - a = Izquierda - d = Derecha - x = Terminar" << endl;
            char cNextMove;
            cin >> cNextMove;
            if (cNextMove == 'x' || comprobarPuntaje(caaBoard)==32)
            {
                imprimirMatriz(caaBoard);
                cout<<"Su puntaje fue de:" << comprobarPuntaje(caaBoard)<<"\n";
                auto end = sc.now();                                                 
                auto time_span = static_cast<chrono::duration<double>>(end - start); 
                cout << "Tiempo de Juego: " << time_span.count() << " segundos\n";
                
               // CREACION Y ASIGNACION DE VARIABLES DE PARTIDAS
                Partida partidaTempo(personasArrayFinal[seleccionJugador].getNombre(),comprobarPuntaje(caaBoard),
                 (cantidadMovimientos - 1000000),time_span.count() );
                partidasArreglo.push_back(partidaTempo);
                continuacion = false;
                break;
            }
            else
            {
                EMove eNextMove = (EMove)cNextMove;
                Move(caaBoard, eNextMove);
                cout << endl;
            }

        } while (continuacion == true);
    }
    else
    {
        cout << "Error Jugador no existente o sin jugadores";
    }
}
void tiempo()
{
}
void menuEspecificoJuego()
{
    int seleccion;
    do
    {
        std::cout << "Seleccione una opcion\n";
        std::cout << "1. Jugar" << std::endl
                  << " 2. Usuarios" << std::endl
                  << " 3. Regresar\n";
        std::cin >> seleccion;
        switch (seleccion)
        {
        case 1:
            jugar();
            break;
        case 2:
            // Ver Reportes
            generacionUsuario();
            break;
        case 3:
            // FIn juego
            cout << "Regresando al menu principal" << endl;
            break;
        default:
            // presiona algo mas
            cout << "No existe esta opcion" << endl;
            break;
        }
    } while (seleccion != 3);
}

// APARTADO DE REPORTES Y VISTAS*-----------------------------------------------------------------

void mostrarReporte()
{
    cout << "-----Partidas Jugadas-------\n";
    for (size_t i = 0; i < partidasArreglo.size(); i++)
    {
       cout<<"Nombre: "<<partidasArreglo[i].getNombre()<<"\n";
       cout<<"Puntos: "<<partidasArreglo[i].getCantidadPunteo()<<"\n";
       cout<<"Pasos: "<<partidasArreglo[i].getPasosTotales()<<"\n";
       cout<<"Tiempo: "<<partidasArreglo[i].getTiempoPartida()<<"\n";


    }
    
}

void menuReporte()
{
    int seleccion;
    do
    {
        std::cout << "Seleccione una opcion\n";
        std::cout << "1. Ver reporte" << std::endl
                  << " 2. Regresar";
        std::cin >> seleccion;
        switch (seleccion)
        {
        case 1:
            mostrarReporte();
            break;

        case 2:
            // FIn juego
            cout << "Regresando al menu principal" << endl;
            break;
        default:
            // presiona algo mas
            cout << "No existe esta opcion" << endl;
            break;
        }
    } while (seleccion != 2);
}

void finTiempo()
{
}
int main()
{
    // puntero

    personas1 *persona = new personas1();

    int seleccion;

    do
    {
        std::cout << "1. Jugar" << std::endl
                  << " 2. Reportes" << std::endl
                  << " 3. Salir\n";
        std::cin >> seleccion;

        switch (seleccion)
        {
        case 1:
            menuEspecificoJuego();

        case 2:
            menuReporte();
            break;
        case 3:
            // FIn juego

            cout << "Gracias por jugar" << endl;
            return 0;
        default:
            // presiona algo mas
            cout << "No existe esta opcion" << endl;
            break;
        }
        // en caso venga el 2, se termina todo
    } while (seleccion != 3);
}